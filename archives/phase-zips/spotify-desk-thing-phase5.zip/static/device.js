/* Phase 5: one paired browser simulates the 4 keys, encoder and touchscreen.
 * Uses only authenticated local JSON/SSE endpoints; no OAuth credentials here. */
'use strict';
const $ = id => document.getElementById(id);
let token = '';
try { token = localStorage.getItem('desk_device_token_v1') || ''; } catch {}
let mode = 'pc', state = null, lastStateTime = 0, stream = null, streamRetry = 0;
let artKey = '', localArtworkObject = null, fallbackTimer = null, commandBusy = false;
const authHeaders = () => ({Authorization: `Bearer ${token}`});
const api = async (path, body=undefined) => {
  const options = {headers:{...authHeaders()}, cache:'no-store'};
  if (body !== undefined) { options.method='POST'; options.headers['Content-Type']='application/json'; options.body=JSON.stringify(body); }
  const response = await fetch(path, options);
  const data = await response.json().catch(()=>({}));
  if (response.status===401) { unpair('Pairing expired or revoked.'); throw new Error('Pair again.'); }
  if (!response.ok || data.ok===false) throw new Error(data.error || `HTTP ${response.status}`);
  return data;
};
function markNetwork(ok, text){$('networkDot').style.background=ok?'#67e6a2':'#5a606b';$('networkText').textContent=text;$('networkText').parentElement.classList.toggle('online',ok);}
function unpair(message=''){
  token='';try{localStorage.removeItem('desk_device_token_v1');}catch{}
  if(stream)stream.abort();stream=null;
  if(fallbackTimer){clearInterval(fallbackTimer);fallbackTimer=null;}
  $('pairOverlay').hidden=false;$('disconnect').hidden=true;
  $('pairError').textContent=message;markNetwork(false,'Not paired');
}
function fmt(ms){const s=Math.floor(Math.max(0,ms||0)/1000);return `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`;}
function renderProgress(){if(!state?.has_playback)return;const length=Math.max(0,Number(state.duration_ms)||0);const t=(Number(state.progress_ms)||0)+(state.playing?Date.now()-lastStateTime:0);$('elapsed').textContent=fmt(Math.min(length,t));$('duration').textContent=fmt(length);$('progress').style.width=length?`${Math.min(100,100*t/length)}%`:'0%';}
async function coverArt(next){
  const key=[mode,next.track_key,next.artwork].join('|');
  if(key===artKey)return;
  artKey=key;
  if(localArtworkObject){URL.revokeObjectURL(localArtworkObject);localArtworkObject=null;}
  $('cover').hidden=true;$('fallback').hidden=false;
  if(!next.artwork)return;
  let src=next.artwork;
  try{
    if(src==='/api/device/artwork'){
      const result=await fetch(src,{headers:authHeaders(),cache:'no-store'});
      if(!result.ok) return;
      const blob=await result.blob();
      if(key!==artKey)return;
      localArtworkObject=URL.createObjectURL(blob);
      src=localArtworkObject;
    } else if(!(src.startsWith('https://'))) return;
    if(key!==artKey)return;
    $('cover').src=src;
    $('cover').hidden=false;$('fallback').hidden=true;
  }catch{}
}
function render(next){
  if(!next || !token)return;
  if(next.mode)mode=next.mode;
  state=next;lastStateTime=Date.now();
  $('pairOverlay').hidden=true;$('disconnect').hidden=false;
  markNetwork(true,`${mode==='pc'?'PC':'WI-FI'} · Paired`);
  $('modeText').textContent=mode==='pc'?'PC MODE':'WI-FI MODE';
  const playing=!!next.playing;
  $('playState').textContent=next.has_playback?(playing?'PLAYING':'PAUSED'):'STANDBY';
  document.querySelector('.live-dot').classList.toggle('playing',playing);
  $('screenPlay').textContent=playing?'Ⅱ':'▶';
  $('title').textContent=next.has_playback?(next.title||'Unknown track'):'Waiting for playback';
  $('artist').textContent=next.has_playback?(next.artist||'Unknown artist'):(next.error||'Start Spotify on the companion');
  $('album').textContent=next.album||'';
  $('deviceName').textContent=next.device || (mode==='pc'?'Local media session':'Spotify Connect');
  $('volumeSource').textContent=next.volume_source==='system'?'SYSTEM':'SPOTIFY';
  const v=Number.isInteger(next.volume)?next.volume:null;
  $('volumeText').textContent=v===null?'--%':`${v}%`;
  $('volumeFill').style.width=v===null?'0%':`${v}%`;
  renderProgress();coverArt(next);
}
async function doCommand(action,value){
  if(!token||commandBusy)return;
  commandBusy=true;
  try{
    const result=await api('/api/device/action',value===undefined?{action}:{action,value});
    if(action==='mode'){
      mode=result.mode;
      artKey='';
    }
    const next=await api('/api/device/state');render(next);
    $('hint').textContent='Command accepted · K1–K4 simulate your mechanical switches';
  }catch(e){$('hint').textContent=`Command failed: ${e.message}`;}
  finally{commandBusy=false;}
}
const keyAction = a => a==='mode' ? doCommand('mode',mode==='pc'?'spotify':'pc') : doCommand(a);
for(const b of document.querySelectorAll('[data-action]')) b.addEventListener('click',()=>keyAction(b.dataset.action));
$('screenPrev').onclick=()=>keyAction('previous');
$('screenPlay').onclick=()=>keyAction('toggle');
$('screenNext').onclick=()=>keyAction('next');
$('volUp').onclick=()=>doCommand('volume_step',5);
$('volDown').onclick=()=>doCommand('volume_step',-5);
$('knob').addEventListener('wheel',e=>{e.preventDefault();doCommand('volume_step',e.deltaY<0?5:-5);},{passive:false});
$('knob').addEventListener('click',()=>doCommand('volume_step',5));
window.addEventListener('keydown',e=>{
  if(e.target instanceof HTMLInputElement)return;
  const actions={'1':'previous','2':'toggle','3':'next','4':'mode'};
  if(actions[e.key]){e.preventDefault();keyAction(actions[e.key]);}
  else if(e.key==='ArrowUp'){e.preventDefault();doCommand('volume_step',5);}
  else if(e.key==='ArrowDown'){e.preventDefault();doCommand('volume_step',-5);}
});
$('disconnect').onclick=()=>unpair();
$('pairForm').addEventListener('submit',async e=>{
  e.preventDefault();$('pairError').textContent='Pairing…';
  try{
    // Pairing intentionally uses no bearer, and each short code is single-use.
    const response=await fetch('/api/device/pair',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({name:'Browser Device Simulator',code:$('code').value.trim()})});
    const body=await response.json();
    if(!response.ok||!body.ok)throw new Error(body.error||'Pairing failed');
    token=body.token;
    try{localStorage.setItem('desk_device_token_v1',token);}catch{}
    $('code').value='';$('pairOverlay').hidden=true;$('pairError').textContent='';
    begin();
  }catch(error){$('pairError').textContent=error.message;}
});
function updateAudio(value){
  const level=Math.min(1,Math.max(0,Number(value?.level)||0));
  $('screenPlay').style.boxShadow=`0 0 ${Math.round(level*22)}px #77ffd177`;
  $('screenPlay').style.filter=`brightness(${(1+level*.18).toFixed(2)})`;
  $('shell').style.setProperty('--audio',String(level));
}
function parseSSE(block){
  let eventName='message',data='';
  for(const line of block.split('\n')){
    if(line.startsWith('event:'))eventName=line.slice(6).trim();
    else if(line.startsWith('data:'))data+=line.slice(5).trim();
  }
  if(!data)return;
  try{
    const payload=JSON.parse(data);
    if(eventName==='state')render(payload);
    if(eventName==='meter')updateAudio(payload);
    if(eventName==='revoked')unpair('Pairing revoked on the companion.');
  }catch{}
}
async function runStream(controller){
  const response=await fetch('/api/device/events',{headers:authHeaders(),cache:'no-store',signal:controller.signal});
  if(response.status===401){unpair('Pairing revoked.');return;}
  if(!response.ok||!response.body)throw Error('Streaming not supported');
  const reader=response.body.getReader(),decoder=new TextDecoder();
  let pending='';
  while(!controller.signal.aborted){
    const chunk=await reader.read();if(chunk.done)break;
    pending+=decoder.decode(chunk.value,{stream:true}).replace(/\r/g,'');
    let boundary;
    while((boundary=pending.indexOf('\n\n'))!==-1){const block=pending.slice(0,boundary);pending=pending.slice(boundary+2);parseSSE(block);}
    if(pending.length>65536)pending='';
  }
}
function begin(){
  if(!token||document.hidden)return;
  if(fallbackTimer){clearInterval(fallbackTimer);fallbackTimer=null;}
  if(stream)stream.abort();
  const controller=new AbortController();stream=controller;
  api('/api/device/state').then(render).catch(e=>{$('hint').textContent=e.message;});
  runStream(controller).catch(()=>{}).finally(()=>{
    if(stream!==controller||!token)return;
    stream=null;markNetwork(false,'Reconnecting…');
    if(!fallbackTimer)fallbackTimer=setInterval(()=>{if(token)api('/api/device/state').then(render).catch(()=>{});},2300);
    setTimeout(()=>{if(token&&!document.hidden&&!stream)begin();},4500);
  });
}
document.addEventListener('visibilitychange',()=>{if(document.hidden){if(stream)stream.abort();stream=null;}else if(token)begin();});
setInterval(renderProgress,250);
if(token)begin();else unpair();
