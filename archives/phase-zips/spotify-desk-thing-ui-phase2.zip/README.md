# Display Spotify Desk Thing — Phase 2 browser UI prototype

This is a local-only Spotify controller, designed at an 800x480 logical layout to explore a potential ESP32-S3 4.3-inch screen. It is **not** ESP32 firmware. No hardware is needed yet.

## Windows PowerShell

In your existing `C:\Users\lukeb\Projects\Display-Spotify-Desk-Thing` project:

```powershell
.\.venv\Scripts\python.exe -m pip install -r .\requirements-ui.txt
$env:SPOTIPY_CLIENT_ID = Read-Host "Enter Spotify Client ID"
.\.venv\Scripts\python.exe .\desk_ui.py
```

Open http://127.0.0.1:8888 in your browser. Start playing music in Spotify and authorize when prompted.

The UI can be controlled by mouse and keyboard (Space, left arrow, right arrow). Drag and release the volume slider to submit a single volume change. It refreshes playback approximately once every 20 seconds.

Use Ctrl+C to stop the local server.

## Privacy and security

- The server binds to `127.0.0.1`, not the local network or the public internet.
- OAuth uses PKCE and caches tokens in `.spotify_token.json` in the project root. Never commit or share that file.
- No client secret is required; the browser receives neither the Client ID nor Spotify access/refresh tokens from the backend.
- There is no remote PC control, ESP32 firmware, or automatic discovery in this stage.
- The refresh poll is conservative and honours a Spotify 429 Retry-After cooldown when present.

Existing `spotify_test.py`, `controls_test.py`, `.spotify_token.json` and `.venv` are left unchanged by extraction.
