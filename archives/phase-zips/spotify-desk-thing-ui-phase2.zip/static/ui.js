'use strict';
const $ = id => document.getElementById(id);
let last = null;
let busy = false;
let blockedUntil = 0;
let lastStatusTime = 0;

function mmss(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
}
function note(message) { $('message').textContent = message; }
function overlay(title, message, button = true) {
  $('overlay').hidden = false;
  $('overlayTitle').textContent = title;
  $('overlayMessage').textContent = message;
  $('connect').hidden = !button;
}
function showState(data) {
  if (!data.connected) {
    $('statusLamp').classList.remove('online');
    $('connectionText').textContent = 'NOT CONNECTED';
    overlay('Connect to Spotify', 'Authorize the Desk Thing prototype with your existing Spotify developer app.');
    setEnabled(false);
    return;
  }
  $('statusLamp').classList.add('online');
  $('connectionText').textContent = 'CONNECTED';
  $('overlay').hidden = true;
  if (!data.has_playback) {
    $('track').textContent = 'Nothing playing';
    $('artist').textContent = 'Start a song in Spotify';
    $('album').textContent = '';
    $('deviceName').textContent = 'No active Spotify device';
    $('cover').hidden = true;
    last = null;
    setEnabled(false);
    return;
  }
  setEnabled(true);
  last = data;
  lastStatusTime = Date.now();
  $('track').textContent = data.title;
  $('artist').textContent = data.artist;
  $('album').textContent = data.album;
  $('deviceName').textContent = data.device;
  $('play').textContent = data.playing ? 'Ⅱ' : '▶';
  $('play').setAttribute('aria-label', data.playing ? 'Pause' : 'Play');
  if (data.artwork) {
    $('cover').src = data.artwork;
    $('cover').hidden = false;
  } else $('cover').hidden = true;
  if (Number.isInteger(data.volume)) {
    $('volume').value = data.volume;
    $('volumeLabel').textContent = `${data.volume}%`;
  } else $('volumeLabel').textContent = '--%';
  $('volume').disabled = !data.supports_volume || !Number.isInteger(data.volume);
  tick();
}
function setEnabled(enabled) {
  for (const name of ['back', 'play', 'next']) $(name).disabled = !enabled;
  $('volume').disabled = !enabled;
}
function tick() {
  if (!last) {
    $('elapsed').textContent = '0:00';
    $('duration').textContent = '0:00';
    $('progressFill').style.width = '0%';
    return;
  }
  const offset = last.playing ? Math.max(0, Date.now() - lastStatusTime) : 0;
  const progress = Math.min(last.duration_ms, last.progress_ms + offset);
  $('elapsed').textContent = mmss(progress);
  $('duration').textContent = mmss(last.duration_ms);
  $('progressFill').style.width = last.duration_ms ? `${100 * progress / last.duration_ms}%` : '0%';
}
async function fetchStatus() {
  if (Date.now() < blockedUntil) return;
  try {
    const response = await fetch('/api/status', { cache: 'no-store' });
    const json = await response.json();
    if (response.status === 429) {
      blockedUntil = Date.now() + (json.retry_after || 60) * 1000;
      note(`Spotify rate limited. Next automatic attempt after ${json.retry_after || 60} seconds.`);
      return;
    }
    if (!response.ok || !json.ok) throw new Error(json.error || `HTTP ${response.status}`);
    showState(json);
    if (json.connected) note('Spotify API mode · Windows/Linux companion mode is planned, not yet implemented.');
  } catch (error) {
    note(`Unable to refresh status: ${error.message}`);
  }
}
async function command(action, value) {
  if (busy || Date.now() < blockedUntil) return;
  busy = true;
  setEnabled(false);
  try {
    const response = await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(value === undefined ? {action} : {action, value}),
    });
    const json = await response.json();
    if (!response.ok || !json.ok) {
      if (response.status === 429) blockedUntil = Date.now() + (json.retry_after || 60) * 1000;
      throw new Error(json.error || `HTTP ${response.status}`);
    }
    note(`${action === 'toggle' ? 'Play/pause' : action} command sent.`);
    // Spotify may take a moment to reflect a successfully accepted command.
    setTimeout(fetchStatus, 1400);
  } catch (error) {
    note(`Command failed: ${error.message}`);
  } finally {
    busy = false;
    if (last) setEnabled(true);
  }
}
$('play').onclick = () => command('toggle');
$('next').onclick = () => command('next');
$('back').onclick = () => command('previous');
$('refresh').onclick = fetchStatus;
$('volume').addEventListener('input', event => {
  $('volumeLabel').textContent = `${event.target.value}%`;
});
$('volume').addEventListener('change', event => command('volume', Number(event.target.value)));
window.addEventListener('keydown', event => {
  if (event.target.matches('input, textarea, select')) return;
  const action = event.code === 'Space' ? 'toggle' : event.code === 'ArrowRight' ? 'next' : event.code === 'ArrowLeft' ? 'previous' : null;
  if (action) { event.preventDefault(); command(action); }
});
setEnabled(false);
fetchStatus();
setInterval(fetchStatus, 20000);
setInterval(tick, 1000);
