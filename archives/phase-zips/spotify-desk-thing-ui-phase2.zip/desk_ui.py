"""Spotify Desk Thing — local desktop touchscreen prototype.

Run from Windows PowerShell with SPOTIPY_CLIENT_ID set. Serves localhost only.
"""

import os
import secrets
import threading
import time
from pathlib import Path
from urllib.parse import urlparse

import spotipy
from flask import Flask, jsonify, redirect, render_template, request, session, url_for
from spotipy.cache_handler import CacheFileHandler
from spotipy.exceptions import SpotifyException
from spotipy.oauth2 import SpotifyPKCE

BASE = Path(__file__).resolve().parent
REDIRECT_URI = "http://127.0.0.1:8888/callback"
SCOPES = "user-read-playback-state user-modify-playback-state"
CLIENT_ID = os.environ.get("SPOTIPY_CLIENT_ID", "").strip()

if not CLIENT_ID:
    raise SystemExit(
        "Missing SPOTIPY_CLIENT_ID. Set it in PowerShell:\n"
        '$env:SPOTIPY_CLIENT_ID = Read-Host "Spotify Client ID"'
    )

app = Flask(__name__)
app.secret_key = secrets.token_bytes(32)
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

auth = SpotifyPKCE(
    client_id=CLIENT_ID,
    redirect_uri=REDIRECT_URI,
    scope=SCOPES,
    cache_handler=CacheFileHandler(cache_path=str(BASE / ".spotify_token.json")),
    open_browser=False,
)
spotify = spotipy.Spotify(
    auth_manager=auth,
    requests_timeout=10,
    retries=0,
    status_retries=0,
)

# Limit requests; the Spotify developer quota can also be shared by other apps.
lock = threading.RLock()
state_cache = {"value": None, "expires": 0.0}
cooldown_until = 0.0
POLL_SECONDS = 20


def error_json(error):
    global cooldown_until
    status = getattr(error, "http_status", 500)
    if not isinstance(status, int) or not 400 <= status <= 599:
        status = 500
    result = {"ok": False, "error": str(getattr(error, "msg", str(error)))[:220]}
    if status == 429:
        headers = getattr(error, "headers", {}) or {}
        try:
            retry_after = max(30, int(headers.get("Retry-After", 60)))
        except (ValueError, TypeError):
            retry_after = 60
        cooldown_until = time.monotonic() + retry_after
        result["retry_after"] = retry_after
        result["error"] = "Spotify rate limit reached. Requests paused."
    elif status == 401:
        result["error"] = "Spotify authorization expired. Select Connect Spotify."
    return jsonify(result), status


def empty_state():
    return {"ok": True, "connected": True, "has_playback": False}


def playback_state():
    state = spotify.current_playback()
    if not state:
        return empty_state()

    item = state.get("item") or {}
    album = item.get("album") or {}
    device = state.get("device") or {}
    artists = item.get("artists") or []
    images = album.get("images") or item.get("images") or []
    artwork = images[0].get("url") if images else None
    # Music images are from Spotify's image CDN, not an arbitrary client URL.
    if artwork and urlparse(artwork).scheme != "https":
        artwork = None
    return {
        "ok": True,
        "connected": True,
        "has_playback": True,
        "title": item.get("name") or "Unknown track",
        "artist": ", ".join(a.get("name", "") for a in artists) or "Unknown artist",
        "album": album.get("name") or "",
        "artwork": artwork,
        "playing": bool(state.get("is_playing")),
        "progress_ms": state.get("progress_ms") or 0,
        "duration_ms": item.get("duration_ms") or 0,
        "device": device.get("name") or "Unknown device",
        "device_id": device.get("id"),
        "volume": device.get("volume_percent"),
        "supports_volume": bool(device.get("supports_volume", True)),
        "updated_at": time.time(),
    }


@app.get("/")
def index():
    return render_template("index.html")


@app.get("/login")
def login():
    state = secrets.token_urlsafe(24)
    session["oauth_state"] = state
    return redirect(auth.get_authorize_url(state=state))


@app.get("/callback")
def callback():
    expected = session.pop("oauth_state", None)
    received = request.args.get("state", "")
    if not expected or not secrets.compare_digest(expected, received):
        return "OAuth state mismatch. Go back and select Connect Spotify again.", 400
    if request.args.get("error"):
        return "Spotify authorization was declined. Go back and try again.", 400
    code = request.args.get("code")
    if not code:
        return "Missing Spotify authorization code.", 400
    try:
        auth.get_access_token(code, check_cache=False)
    except Exception:
        return "Spotify authorization failed. Return to the main page and try again.", 400
    with lock:
        state_cache["expires"] = 0
    return redirect(url_for("index"))


@app.get("/api/status")
def get_status():
    global cooldown_until
    with lock:
        if not auth.get_cached_token():
            return jsonify({"ok": True, "connected": False, "has_playback": False})
        now = time.monotonic()
        if now < cooldown_until:
            return jsonify({
                "ok": False,
                "error": "Spotify rate limit cooldown active.",
                "retry_after": round(cooldown_until - now),
            }), 429
        if state_cache["expires"] > now and state_cache["value"] is not None:
            return jsonify(state_cache["value"])
        try:
            value = playback_state()
            state_cache.update(value=value, expires=time.monotonic() + POLL_SECONDS)
            return jsonify(value)
        except SpotifyException as error:
            return error_json(error)
        except Exception:
            return jsonify({"ok": False, "error": "Unable to read Spotify playback."}), 503


@app.post("/api/control")
def control():
    # Only local web pages can send browser-based commands.
    origin = request.headers.get("Origin")
    if origin not in (None, "http://127.0.0.1:8888"):
        return jsonify({"ok": False, "error": "Invalid request origin."}), 403
    if not request.is_json:
        return jsonify({"ok": False, "error": "Expected JSON."}), 415
    body = request.get_json(silent=True) or {}
    action = body.get("action")
    if action not in {"toggle", "next", "previous", "volume"}:
        return jsonify({"ok": False, "error": "Unknown action."}), 400

    with lock:
        if not auth.get_cached_token():
            return jsonify({"ok": False, "error": "Connect Spotify first."}), 401
        if time.monotonic() < cooldown_until:
            return jsonify({"ok": False, "error": "Spotify rate limit cooldown active."}), 429
        try:
            current = spotify.current_playback()
            device = (current or {}).get("device") or {}
            device_id = device.get("id")
            if not current or not device_id:
                return jsonify({"ok": False, "error": "Start playback in Spotify first."}), 409
            if action == "toggle":
                if current.get("is_playing"):
                    spotify.pause_playback(device_id=device_id)
                else:
                    spotify.start_playback(device_id=device_id)
            elif action == "next":
                spotify.next_track(device_id=device_id)
            elif action == "previous":
                spotify.previous_track(device_id=device_id)
            elif action == "volume":
                volume = body.get("value")
                if type(volume) is not int or not 0 <= volume <= 100:
                    return jsonify({"ok": False, "error": "Volume must be 0–100."}), 400
                if device.get("supports_volume") is False:
                    return jsonify({"ok": False, "error": "This device does not support volume control."}), 409
                spotify.volume(volume_percent=volume, device_id=device_id)
            state_cache["expires"] = 0
            return jsonify({"ok": True, "message": "Command sent"})
        except SpotifyException as error:
            return error_json(error)
        except Exception:
            return jsonify({"ok": False, "error": "Unable to send Spotify command."}), 503


if __name__ == "__main__":
    print("Spotify Desk Thing — browser prototype")
    print("Open http://127.0.0.1:8888")
    print("Press Ctrl+C to stop. Never expose this prototype to the internet.")
    app.run(host="127.0.0.1", port=8888, debug=False, use_reloader=False)
