'use strict';
const $ = id => document.getElementById(id);
let last = null;
let busy = false;
let blockedUntil = 0;
let lastStatusTime = 0;

function iconPlay() {
  return `<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M8 5.5v13l10-6.5z"/></svg>`;
}
function iconPause() {
  return `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="7" y="5.5" width="3.8" height="13" rx="1"/><rect x="13.2" y="5.5" width="3.8" height="13" rx="1"/></svg>`;
}
function iconPrevious() {
  return `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="6" width="2.4" height="12" rx="1"/><path d="M18.5 6.7v10.6a.8.8 0 0 1-1.24.67L10 12.66a.8.8 0 0 1 0-1.32l7.26-5.31a.8.8 0 0 1 1.24.67Z"/><path d="M13.5 6.7v10.6a.8.8 0 0 1-1.24.67L5 12.66a.8.8 0 0 1 0-1.32l7.26-5.31a.8.8 0 0 1 1.24.67Z"/></svg>`;
}
function iconNext() {
  return `<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="16.6" y="6" width="2.4" height="12" rx="1"/><path d="M5.5 6.7v10.6a.8.8 0 0 0 1.24.67L14 12.66a.8.8 0 0 0 0-1.32L6.74 6.03a.8.8 0 0 0-1.24.67Z"/><path d="M10.5 6.7v10.6a.8.8 0 0 0 1.24.67L19 12.66a.8.8 0 0 0 0-1.32l-7.26-5.31a.8.8 0 0 0-1.24.67Z"/></svg>`;
}
function renderTransportIcons(isPlaying) {
  $('back').innerHTML = iconPrevious();
  $('next').innerHTML = iconNext();
  $('play').innerHTML = isPlaying ? iconPause() : iconPlay();
}

function mmss(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
}
function note(message) { $('message').textContent = message; }
function overlay(title, message, button = true) {
  $('overlay').hidden = false;
  $('overlayTitle').textContent = title;
  $('overlayMessage').textContent = message;
  $('connect').hidden = !button;
}
function showState(data) {
  renderTransportIcons(false);
  if (!data.connected) {
    $('statusLamp').classList.remove('online');
    $('connectionText').textContent = 'NOT CONNECTED';
    overlay('Connect to Spotify', 'Authorize the Desk Thing prototype with your existing Spotify developer app.');
    setEnabled(false);
    return;
  }
  $('statusLamp').classList.add('online');
  $('connectionText').textContent = 'CONNECTED';
  $('overlay').hidden = true;
  if (!data.has_playback) {
    $('track').textContent = 'Nothing playing';
    $('artist').textContent = 'Start a song in Spotify';
    $('album').textContent = '';
    $('deviceName').textContent = 'No active Spotify device';
    $('cover').hidden = true;
    $('volumeLabel').textContent = '--%';
    last = null;
    tick();
    setEnabled(false);
    return;
  }
  setEnabled(true);
  last = data;
  lastStatusTime = Date.now();
  $('track').textContent = data.title;
  $('artist').textContent = data.artist;
  $('album').textContent = data.album;
  $('deviceName').textContent = data.device;
  renderTransportIcons(data.playing);
  $('play').setAttribute('aria-label', data.playing ? 'Pause' : 'Play');
  if (data.artwork) {
    $('cover').src = data.artwork;
    $('cover').hidden = false;
  } else $('cover').hidden = true;
  if (Number.isInteger(data.volume)) {
    $('volume').value = data.volume;
    $('volumeLabel').textContent = `${data.volume}%`;
  } else $('volumeLabel').textContent = '--%';
  $('volume').disabled = !data.supports_volume || !Number.isInteger(data.volume);
  tick();
}
function setEnabled(enabled) {
  for (const name of ['back', 'play', 'next']) $(name).disabled = !enabled;
  $('volume').disabled = !enabled;
}
function tick() {
  if (!last) {
    $('elapsed').textContent = '0:00';
    $('duration').textContent = '0:00';
    $('progressFill').style.width = '0%';
    return;
  }
  const offset = last.playing ? Math.max(0, Date.now() - lastStatusTime) : 0;
  const progress = Math.min(last.duration_ms, last.progress_ms + offset);
  $('elapsed').textContent = mmss(progress);
  $('duration').textContent = mmss(last.duration_ms);
  $('progressFill').style.width = last.duration_ms ? `${100 * progress / last.duration_ms}%` : '0%';
}
async function fetchStatus(force = false) {
  if (Date.now() < blockedUntil) return;
  try {
    const response = await fetch(force ? '/api/status?fresh=1' : '/api/status', { cache: 'no-store' });
    const json = await response.json();
    if (response.status === 429) {
      blockedUntil = Date.now() + (json.retry_after || 60) * 1000;
      note(`Spotify rate limited. Next automatic attempt after ${json.retry_after || 60} seconds.`);
      return;
    }
    if (!response.ok || !json.ok) throw new Error(json.error || `HTTP ${response.status}`);
    showState(json);
    if (json.connected) note(json.has_playback
      ? 'Spotify API mode · Windows/Linux companion mode is planned, not yet implemented.'
      : 'No active Spotify playback. Start a song in Spotify, then click Refresh track. Or select Find Spotify devices.');
  } catch (error) {
    note(`Unable to refresh status: ${error.message}`);
  }
}
async function command(action, value) {
  if (busy || Date.now() < blockedUntil) return;
  busy = true;
  setEnabled(false);
  try {
    const response = await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(value === undefined ? {action} : {action, value}),
    });
    const json = await response.json();
    if (!response.ok || !json.ok) {
      if (response.status === 429) blockedUntil = Date.now() + (json.retry_after || 60) * 1000;
      if (response.status === 409) {
        await fetchStatus(true); // Remove any stale track immediately.
      }
      throw new Error(json.error || `HTTP ${response.status}`);
    }
    note(`${action === 'toggle' ? 'Play/pause' : action} command sent.`);
    // Spotify may take a moment to reflect a successfully accepted command.
    setTimeout(fetchStatus, 1400);
  } catch (error) {
    note(`Command failed: ${error.message}`);
  } finally {
    busy = false;
    if (last) setEnabled(true);
  }
}
$('play').onclick = () => command('toggle');
$('next').onclick = () => command('next');
$('back').onclick = () => command('previous');
$('refresh').onclick = () => fetchStatus(true);
$('volume').addEventListener('input', event => {
  $('volumeLabel').textContent = `${event.target.value}%`;
});
$('volume').addEventListener('change', event => command('volume', Number(event.target.value)));
window.addEventListener('keydown', event => {
  if (event.target.matches('input, textarea, select')) return;
  const action = event.code === 'Space' ? 'toggle' : event.code === 'ArrowRight' ? 'next' : event.code === 'ArrowLeft' ? 'previous' : null;
  if (action) { event.preventDefault(); command(action); }
});
async function findDevices() {
  const panel = $('devicePicker');
  panel.hidden = false;
  panel.replaceChildren();
  const heading = document.createElement('h2');
  heading.textContent = 'Spotify Connect devices';
  panel.append(heading);
  const info = document.createElement('p');
  info.textContent = 'Looking for available devices…';
  panel.append(info);
  try {
    const response = await fetch('/api/devices', {cache:'no-store'});
    const data = await response.json();
    if (!response.ok || !data.ok) {
      if (response.status === 429) blockedUntil = Date.now() + (data.retry_after || 60) * 1000;
      throw new Error(data.error || `HTTP ${response.status}`);
    }
    if (!data.devices.length) {
      info.textContent = 'No Spotify devices found. Open Spotify on your PC or phone, start a song, then click Find Spotify devices again.';
      return;
    }
    info.textContent = 'Choose where Spotify should play. Selecting a device will not automatically start music.';
    for (const d of data.devices) {
      const line = document.createElement('div');
      line.className = 'device-option';
      const label = document.createElement('span');
      label.textContent = `${d.name} (${d.type})${d.active ? ' · active' : ''}`;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = d.restricted ? 'Unavailable' : (d.active ? 'Use device' : 'Select device');
      btn.disabled = d.restricted;
      btn.onclick = async () => {
        btn.disabled = true;
        try {
          const r = await fetch('/api/activate', {
            method:'POST', headers:{'Content-Type':'application/json'},
            body:JSON.stringify({device_id:d.id})
          });
          const result = await r.json();
          if (!r.ok || !result.ok) {
            if (r.status === 429) blockedUntil = Date.now() + (result.retry_after || 60) * 1000;
            throw new Error(result.error || `HTTP ${r.status}`);
          }
          panel.hidden = true;
          await fetchStatus(true);
          note(result.message);
        } catch (e) {
          note(`Device selection failed: ${e.message}`);
          btn.disabled = false;
        }
      };
      line.append(label, btn);
      panel.append(line);
    }
  } catch(e) { info.textContent = `Device lookup failed: ${e.message}`; }
}
$('devices').onclick = findDevices;
renderTransportIcons(false);
setEnabled(false);
fetchStatus();
setInterval(fetchStatus, 20000);
setInterval(tick, 1000);
