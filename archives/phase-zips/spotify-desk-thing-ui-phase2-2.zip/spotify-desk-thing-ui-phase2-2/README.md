# Phase 2.1 — active-device and refresh fixes

**Changes from Phase 2**
- Refresh track now bypasses the 20-second status cache.
- If the active playback session disappears, control requests report an actionable message and clear the old track immediately.
- Find Spotify devices manually lists Spotify Connect devices; you may select one with a deliberate click. Selection uses `transfer_playback(..., force_play=False)`, so it does **not** deliberately start music.
- No extra Spotify requests are added to the automatic 20-second status poll.
- The token cache and previous API test scripts are not changed.

## Install (Windows PowerShell)

1. Stop the running Python UI server with Ctrl+C in its terminal.
2. Download `spotify-desk-thing-ui-phase2-1.zip` to Downloads.
3. In PowerShell:

```powershell
$Project = "$HOME\Projects\Display-Spotify-Desk-Thing"
$Zip = "$HOME\Downloads\spotify-desk-thing-ui-phase2-1.zip"
Set-Location $Project
Expand-Archive -Path $Zip -DestinationPath $Project -Force
if (-not $env:SPOTIPY_CLIENT_ID) { $env:SPOTIPY_CLIENT_ID = Read-Host 'Enter Spotify Client ID' }
.\.venv\Scripts\python.exe .\desk_ui.py
```

4. Open http://127.0.0.1:8888, start playing Spotify, click **Refresh track** and test **Pause** / **Next**.
5. If the display says `No active Spotify device`, click **Find Spotify devices**. Select your PC if shown, then start/resume a song in Spotify and click **Refresh track**. Some Spotify devices may reject Web API controls even if listed.

Server remains bound to loopback `127.0.0.1`. Never expose it to the internet.

The HTTP 404 for `/favicon.ico` in the earlier server log is harmless and unrelated to controls.

Original prototype instructions:

# Display Spotify Desk Thing — Phase 2 browser UI prototype

This is a local-only Spotify controller, designed at an 800x480 logical layout to explore a potential ESP32-S3 4.3-inch screen. It is **not** ESP32 firmware. No hardware is needed yet.

## Windows PowerShell

In your existing `C:\Users\lukeb\Projects\Display-Spotify-Desk-Thing` project:

```powershell
.\.venv\Scripts\python.exe -m pip install -r .\requirements-ui.txt
$env:SPOTIPY_CLIENT_ID = Read-Host "Enter Spotify Client ID"
.\.venv\Scripts\python.exe .\desk_ui.py
```

Open http://127.0.0.1:8888 in your browser. Start playing music in Spotify and authorize when prompted.

The UI can be controlled by mouse and keyboard (Space, left arrow, right arrow). Drag and release the volume slider to submit a single volume change. It refreshes playback approximately once every 20 seconds.

Use Ctrl+C to stop the local server.

## Privacy and security

- The server binds to `127.0.0.1`, not the local network or the public internet.
- OAuth uses PKCE and caches tokens in `.spotify_token.json` in the project root. Never commit or share that file.
- No client secret is required; the browser receives neither the Client ID nor Spotify access/refresh tokens from the backend.
- There is no remote PC control, ESP32 firmware, or automatic discovery in this stage.
- The refresh poll is conservative and honours a Spotify 429 Retry-After cooldown when present.

Existing `spotify_test.py`, `controls_test.py`, `.spotify_token.json` and `.venv` are left unchanged by extraction.
