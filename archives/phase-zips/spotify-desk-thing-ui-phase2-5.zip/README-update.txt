Spotify Desk Thing — Phase 2.5 / next & previous responsiveness

Improvements:
- Immediate "Skipping track…" or "Going back…" on button press.
- Early bounded confirmations (approx. 280ms, 850ms and 1500ms after earlier attempts).
- Ignores briefly stale Spotify data until changed track is confirmed.
- Handles Spotify previous-track behavior that restarts the same song.
- Retries verification if background refresh was already in progress.
- Returns to the last known display if Spotify never confirms within 7 seconds.
- Normal 5-second foreground / 20-second background polling unchanged.
- Keeps working controls, SVG play/pause buttons, and dynamic volume icon.
- No dependencies, OAuth, token, or redirect changes.

STOP server with Ctrl+C, unzip into project root with -Force and restart:

  $Project = "$HOME\Projects\Display-Spotify-Desk-Thing"
  $Zip = "$HOME\Downloads\spotify-desk-thing-ui-phase2-5.zip"
  Set-Location $Project
  Expand-Archive -LiteralPath $Zip -DestinationPath $Project -Force
  Select-String -Path .\templates\index.html -Pattern "ui.js\?v=2.5"
  .\.venv\Scripts\python.exe .\desk_ui.py

Open http://127.0.0.1:8888 and hard refresh (Ctrl+F5).

Important: A public Spotify API cannot make external desktop button
changes instant; a future local Windows/MPRIS companion is planned.
