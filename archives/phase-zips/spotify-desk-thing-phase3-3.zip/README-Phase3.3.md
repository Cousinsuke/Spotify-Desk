# Spotify Desk Thing — Phase 3.3: quieter Windows audio feed

## Changes
- The browser now uses a single `EventSource` connection to `/api/pc/audio/stream` instead of sending a new GET every 160 ms.
- Live audio levels are streamed as short JSON SSE messages about every 100 ms. No raw audio is transmitted.
- When PC mode is disabled or the page is hidden, the browser closes the stream.
- If streaming fails, it falls back to 300 ms polling with one in-flight request at a time, and periodically retries SSE.
- Spotify Web API requests, existing playback commands, artwork matching, and the selected Windows audio output are unchanged.

## Installation (Windows PowerShell)
1. Stop the server with Ctrl+C.
2. Download the zip into Downloads, then run:

```powershell
Set-Location "$HOME\Projects\Display-Spotify-Desk-Thing"
Expand-Archive -LiteralPath "$HOME\Downloads\spotify-desk-thing-phase3-3.zip" -DestinationPath . -Force
.\.venv\Scripts\python.exe .\desk_ui.py
```

Open http://127.0.0.1:8888 and press Ctrl+F5. Switch to **PC**.

The terminal should display a single `GET /api/pc/audio/stream` request on entering PC mode, instead of the repeated `GET /api/pc/audio` lines. Spotify controls, Windows local controls and the A50 Game loopback glow should still work.

If streaming cannot connect, the old endpoint still works at a lower frequency.

**Security:** Flask remains bound to 127.0.0.1. The audio endpoint contains only the estimated amplitude value; audio is not saved.
