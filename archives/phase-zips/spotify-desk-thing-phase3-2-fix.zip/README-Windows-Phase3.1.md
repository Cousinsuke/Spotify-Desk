# Spotify Desk Thing — Windows 11 Companion (Phase 3.1)

This is an incremental extension of the working Phase 2.7 browser prototype.
It **does not** replace your Spotify developer login, `.spotify_token.json`, or the standalone Spotify Wi-Fi mode.

## Install — Windows PowerShell

Stop `desk_ui.py` with Ctrl+C. Back up your project folder if you have made personal edits since Phase 2.7.
Download `spotify-desk-thing-phase3-1.zip` to Downloads, then run:

```powershell
$Project = "$HOME\Projects\Display-Spotify-Desk-Thing"
$Zip = "$HOME\Downloads\spotify-desk-thing-phase3-1.zip"
Set-Location $Project
Expand-Archive -LiteralPath $Zip -DestinationPath $Project -Force
.\.venv\Scripts\python.exe -m pip install -r .\requirements-windows.txt
.\.venv\Scripts\python.exe .\windows_diagnostics.py
```

If diagnostics succeed, start the browser:

```powershell
if (-not $env:SPOTIPY_CLIENT_ID) { $env:SPOTIPY_CLIENT_ID = Read-Host 'Enter Spotify Client ID' }
.\.venv\Scripts\python.exe .\desk_ui.py
```

Open http://127.0.0.1:8888/ and press Ctrl+F5. Select **PC** in the top bar. Select **WI-FI** to return to standalone Spotify control.

## What to test

1. Start music in the native Spotify Windows application. Does the PC mode show the track, artist, and play/pause status?
2. Pause Spotify **in the Spotify application**. Does the page change within ~1 second (depending on Windows session availability)?
3. Click Play/Pause, Next and Previous in PC mode. Confirm the desktop app responds.
4. Move the PC-mode volume slider. It controls the **Windows default output volume** (not Spotify Connect's volume).
5. Watch the warm/cool album-colour glow. When the speaker loopback meter is available, does its brightness move gently with the volume of the actual audio output?
6. Switch back to WI-FI and confirm your original Spotify API controls still work.

## Audio capture details and privacy

The optional SoundCard meter reads the **Windows default speaker output mix**, not the microphone and not Spotify's protected audio data. It may react to other PC sounds such as notifications. Only a normalized amplitude value reaches the browser. The sample arrays are temporary and not saved. This is why there is no 'audio reacts to Spotify only' guarantee yet.

If music is playing through a different device (e.g., Astro A50 headset), list devices using `windows_diagnostics.py` and select the matching speaker using an environment variable in the *same* PowerShell window before launching:

```powershell
$env:DESK_AUDIO_DEVICE = 'Astro A50'
.\.venv\Scripts\python.exe .\desk_ui.py
```

Remove the override with `Remove-Item Env:\DESK_AUDIO_DEVICE` to use your default speaker again. SoundCard device-name matching may be ambiguous; use an exact or distinctive substring of a listed speaker.

If the sound meter cannot initialise, PC controls should still work; the glow uses the original subtle timed animation and a diagnostic message is displayed below the device.

## Architecture notes

- `windows_companion.py` uses the Windows GlobalSystemMediaTransportControlsSessionManager and Python 3.13 compatible WinRT bindings. Spotify is preferred when it exposes a Windows media session; otherwise Windows' current media session is used.
- `/api/pc/status` reads local media information; the browser checks about every 800 ms while visible, with a short server cache. This phase is **not event-subscription based yet**.
- `/api/pc/control` handles local play/pause/skip and Windows master-volume commands.
- `/api/pc/audio` returns a single amplitude value from WASAPI loopback, requested about every 160 ms while PC mode is active.
- `/api/pc/artwork` optionally serves Windows' session thumbnail locally; if unavailable, placeholder artwork is shown. Some media applications do not provide thumbnails or timeline information.
- Existing `/api/status`, `/api/control`, and `/api/devices` remain unchanged for Spotify API mode.
- All endpoints stay on `127.0.0.1:8888`; **do not expose Flask's development server to the internet**.
- The browser source-selection buttons are only a prototype. The hardware firmware / ESP32 mode protocol remains a future phase.

### Known limitations

- Local media read latency depends on whether Windows/Spotify publishes media transport information.
- Thumbnail extraction is best-effort. If the read fails on a specific Windows SDK package combination, playback functions can still work with placeholder artwork.
- Audio-reactive capture measures whichever endpoint SoundCard selects, not every audio output, so an Astro A50 headset might require selecting its output explicitly.
- The Flask server is still a local development prototype rather than a background Windows service.

Send the output of `windows_diagnostics.py`, and any browser console/PowerShell errors, before we declare Phase 3.1 validated.


## Phase 3.2 dependency correction

Added `winrt-Windows.Foundation.Collections==3.2.1` to `requirements-windows.txt` to fix the missing `winrt.windows.foundation.collections` module reported by Phase 3.1 diagnostics. No application logic changed.
