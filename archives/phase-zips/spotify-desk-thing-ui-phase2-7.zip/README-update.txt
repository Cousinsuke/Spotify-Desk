Spotify Desk Thing — Phase 2.7 (ambient glow clipping fix)

Contains only static/ui.css and templates/index.html.
Extract directly into your existing project root. Do not replace desk_ui.py, your token cache, or other files.

Changes:
- Fixed neutral browser page background (no album colour beyond device).
- Removed album-reactive glow pseudo-element outside the device.
- Fixed small dot above the device to standard green.
- Retained album artwork palette and breathing glow inside the 800 x 480 preview.
- Kept UI logic, controls, API polling and device picker unchanged.

Windows PowerShell:
  Stop the current server with Ctrl+C
  $Project = "$HOME\Projects\Display-Spotify-Desk-Thing"
  $Zip = "$HOME\Downloads\spotify-desk-thing-ui-phase2-7.zip"
  Set-Location $Project
  Expand-Archive -LiteralPath $Zip -DestinationPath $Project -Force
  Select-String -Path ".\templates\index.html" -Pattern "ui.css\?v=2.7"
  .\.venv\Scripts\python.exe .\desk_ui.py

Open http://127.0.0.1:8888 and use Ctrl+F5.
