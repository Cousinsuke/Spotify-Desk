'use strict';
const $ = id => document.getElementById(id);
let last = null;
let busy = false;
let blockedUntil = 0;
let lastStatusTime = 0;
let statusInFlight = false;
let playbackOverride = null;
const VISIBLE_REFRESH_MS = 5000;
const HIDDEN_REFRESH_MS = 20000;


/* Icons are SVG instead of font glyphs, preventing font-dependent misalignment. */
// Both icons share a 24px coordinate space, 28px rendered size and 15px visual height.
// Slight optical offset on the triangle balances it against the symmetrical pause bars.
const PLAY_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6.5 4.5c0-.5.55-.8.99-.5L19.4 11.5c.39.25.39.75 0 1L7.49 20c-.44.3-.99 0-.99-.5V4.5Z"/></svg>';
const PAUSE_ICON = '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5.8" y="4.5" width="5.15" height="15" rx="1.6"/><rect x="13.05" y="4.5" width="5.15" height="15" rx="1.6"/></svg>';
function setPlaybackIcon(isPlaying) {
  const button = $('play');
  button.innerHTML = isPlaying ? PAUSE_ICON : PLAY_ICON;
  button.dataset.state = isPlaying ? 'playing' : 'paused';
  button.setAttribute('aria-label', isPlaying ? 'Pause' : 'Play');
}
function setVolumeIcon(percent) {
  const icon = $('volumeIcon');
  const known = Number.isInteger(percent) && percent >= 0 && percent <= 100;
  const level = !known ? 'unknown' : percent === 0 ? 'muted' : percent <= 33 ? 'low' : percent <= 66 ? 'medium' : 'high';
  const speaker = '<path d="M11 5 6 9H3v6h3l5 4V5Z"/>';
  const wave1 = '<path d="M14.5 9a4.2 4.2 0 0 1 0 6"/>';
  const wave2 = '<path d="M17 6.7a7.2 7.2 0 0 1 0 10.6"/>';
  const wave3 = '<path d="M19 4.6a10.5 10.5 0 0 1 0 14.8"/>';
  const mute = '<path d="m15 9 6 6m0-6-6 6"/>';
  let paths = speaker;
  if (level === 'muted') paths += mute;
  else if (level === 'low') paths += wave1;
  else if (level === 'medium') paths += wave1 + wave2;
  else if (level === 'high') paths += wave1 + wave2 + wave3;
  icon.innerHTML = `<svg viewBox="0 0 24 24" aria-hidden="true">${paths}</svg>`;
  icon.setAttribute('aria-label', known ? `Volume ${percent}%, ${level}` : 'Volume unavailable');
}

function mmss(ms) {
  const total = Math.max(0, Math.floor(ms / 1000));
  return `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
}
function note(message) { $('message').textContent = message; }
function overlay(title, message, button = true) {
  $('overlay').hidden = false;
  $('overlayTitle').textContent = title;
  $('overlayMessage').textContent = message;
  $('connect').hidden = !button;
}
function showState(data) {
  if (playbackOverride) {
    if (Date.now() >= playbackOverride.expires || !data.has_playback ||
        data.device_id !== playbackOverride.deviceId ||
        data.playing === playbackOverride.playing) {
      playbackOverride = null;
    } else {
      // Temporarily preserve the pressed state while Spotify catches up.
      data = {
        ...data,
        playing: playbackOverride.playing,
        progress_ms: playbackOverride.progressMs,
      };
    }
  }
  if (!data.connected) {
    setPlaybackIcon(false);
    setVolumeIcon(null);
    $('statusLamp').classList.remove('online');
    $('connectionText').textContent = 'NOT CONNECTED';
    overlay('Connect to Spotify', 'Authorize the Desk Thing prototype with your existing Spotify developer app.');
    setEnabled(false);
    return;
  }
  $('statusLamp').classList.add('online');
  $('connectionText').textContent = 'CONNECTED';
  $('overlay').hidden = true;
  if (!data.has_playback) {
    setPlaybackIcon(false);
    setVolumeIcon(null);
    $('track').textContent = 'Nothing playing';
    $('artist').textContent = 'Start a song in Spotify';
    $('album').textContent = '';
    $('deviceName').textContent = 'No active Spotify device';
    $('cover').hidden = true;
    $('volumeLabel').textContent = '--%';
    last = null;
    tick();
    setEnabled(false);
    return;
  }
  setEnabled(true);
  last = data;
  lastStatusTime = Date.now();
  $('track').textContent = data.title;
  $('artist').textContent = data.artist;
  $('album').textContent = data.album;
  $('deviceName').textContent = data.device;
  setPlaybackIcon(data.playing);
  if (data.artwork) {
    $('cover').src = data.artwork;
    $('cover').hidden = false;
  } else $('cover').hidden = true;
  if (Number.isInteger(data.volume)) {
    if (!$('volume').matches(':active')) {
      $('volume').value = data.volume;
      $('volumeLabel').textContent = `${data.volume}%`;
      setVolumeIcon(data.volume);
    }
  } else {
    $('volumeLabel').textContent = '--%';
    setVolumeIcon(null);
  }
  $('volume').disabled = !data.supports_volume || !Number.isInteger(data.volume);
  tick();
}
function setEnabled(enabled) {
  for (const name of ['back', 'play', 'next']) $(name).disabled = !enabled;
  $('volume').disabled = !enabled;
}
function tick() {
  if (!last) {
    $('elapsed').textContent = '0:00';
    $('duration').textContent = '0:00';
    $('progressFill').style.width = '0%';
    return;
  }
  const offset = last.playing ? Math.max(0, Date.now() - lastStatusTime) : 0;
  const progress = Math.min(last.duration_ms, last.progress_ms + offset);
  $('elapsed').textContent = mmss(progress);
  $('duration').textContent = mmss(last.duration_ms);
  $('progressFill').style.width = last.duration_ms ? `${100 * progress / last.duration_ms}%` : '0%';
}
async function fetchStatus(force = false) {
  if (statusInFlight || busy || Date.now() < blockedUntil) return;
  statusInFlight = true;
  try {
    const response = await fetch(force ? '/api/status?fresh=1' : '/api/status', { cache: 'no-store' });
    const json = await response.json();
    if (response.status === 429) {
      blockedUntil = Date.now() + (json.retry_after || 60) * 1000;
      note(`Spotify rate limited. Next automatic attempt after ${json.retry_after || 60} seconds.`);
      return;
    }
    if (!response.ok || !json.ok) throw new Error(json.error || `HTTP ${response.status}`);
    showState(json);
    if (json.connected) note(json.has_playback
      ? 'Spotify API mode · Windows/Linux companion mode is planned, not yet implemented.'
      : 'No active Spotify playback. Start a song in Spotify, then click Refresh track. Or select Find Spotify devices.');
  } catch (error) {
    note(`Unable to refresh status: ${error.message}`);
  } finally {
    statusInFlight = false;
  }
}
function optimisticUpdate(action, value) {
  if (!last) return;
  if (action === 'toggle') {
    const elapsed = last.playing ? Math.max(0, Date.now() - lastStatusTime) : 0;
    const progressMs = Math.min(last.duration_ms, last.progress_ms + elapsed);
    const nowPlaying = !last.playing;
    last = { ...last, playing: nowPlaying, progress_ms: progressMs };
    lastStatusTime = Date.now();
    playbackOverride = {
      deviceId: last.device_id,
      playing: nowPlaying,
      progressMs,
      expires: Date.now() + 3500,
    };
    setPlaybackIcon(nowPlaying);
    tick();
  } else if (action === 'volume' && Number.isInteger(value)) {
    last = { ...last, volume: value };
    $('volume').value = value;
    $('volumeLabel').textContent = `${value}%`;
    setVolumeIcon(value);
  } else if (action === 'next' || action === 'previous') {
    note('Changing track…');
  }
}
async function command(action, value) {
  if (busy || Date.now() < blockedUntil) return;
  busy = true;
  const previousState = last ? {...last} : null;
  const previousStatusTime = lastStatusTime;
  optimisticUpdate(action, value);
  try {
    const response = await fetch('/api/control', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(value === undefined ? {action} : {action, value}),
    });
    const json = await response.json();
    if (!response.ok || !json.ok) {
      if (response.status === 429) blockedUntil = Date.now() + (json.retry_after || 60) * 1000;
      if (response.status === 409) {
        await fetchStatus(true); // Remove any stale track immediately.
      }
      throw new Error(json.error || `HTTP ${response.status}`);
    }
    note(`${action === 'toggle' ? 'Play/pause' : action} command sent.`);
    // Verify shortly afterwards, then once more if Spotify was still propagating.
    setTimeout(() => fetchStatus(true), 950);
    setTimeout(() => fetchStatus(true), 3000);
  } catch (error) {
    playbackOverride = null;
    if (previousState) {
      last = previousState;
      lastStatusTime = previousStatusTime;
      setPlaybackIcon(previousState.playing);
      if (Number.isInteger(previousState.volume)) {
        $('volume').value = previousState.volume;
        $('volumeLabel').textContent = `${previousState.volume}%`;
        setVolumeIcon(previousState.volume);
      }
      tick();
    }
    note(`Command failed: ${error.message}`);
    // Reconcile with Spotify as soon as possible; respect any 429 cooldown.
    setTimeout(() => fetchStatus(true), 250);
  } finally {
    busy = false;
    if (last) setEnabled(true);
  }
}
$('play').onclick = () => command('toggle');
$('next').onclick = () => command('next');
$('back').onclick = () => command('previous');
$('refresh').onclick = () => fetchStatus(true);
$('volume').addEventListener('input', event => {
  $('volumeLabel').textContent = `${event.target.value}%`;
  setVolumeIcon(Number(event.target.value));
});
$('volume').addEventListener('change', event => command('volume', Number(event.target.value)));
window.addEventListener('keydown', event => {
  if (event.target.matches('input, textarea, select')) return;
  const action = event.code === 'Space' ? 'toggle' : event.code === 'ArrowRight' ? 'next' : event.code === 'ArrowLeft' ? 'previous' : null;
  if (action) { event.preventDefault(); command(action); }
});
async function findDevices() {
  const panel = $('devicePicker');
  panel.hidden = false;
  panel.replaceChildren();
  const heading = document.createElement('h2');
  heading.textContent = 'Spotify Connect devices';
  panel.append(heading);
  const info = document.createElement('p');
  info.textContent = 'Looking for available devices…';
  panel.append(info);
  try {
    const response = await fetch('/api/devices', {cache:'no-store'});
    const data = await response.json();
    if (!response.ok || !data.ok) {
      if (response.status === 429) blockedUntil = Date.now() + (data.retry_after || 60) * 1000;
      throw new Error(data.error || `HTTP ${response.status}`);
    }
    if (!data.devices.length) {
      info.textContent = 'No Spotify devices found. Open Spotify on your PC or phone, start a song, then click Find Spotify devices again.';
      return;
    }
    info.textContent = 'Choose where Spotify should play. Selecting a device will not automatically start music.';
    for (const d of data.devices) {
      const line = document.createElement('div');
      line.className = 'device-option';
      const label = document.createElement('span');
      label.textContent = `${d.name} (${d.type})${d.active ? ' · active' : ''}`;
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.textContent = d.restricted ? 'Unavailable' : (d.active ? 'Use device' : 'Select device');
      btn.disabled = d.restricted;
      btn.onclick = async () => {
        btn.disabled = true;
        try {
          const r = await fetch('/api/activate', {
            method:'POST', headers:{'Content-Type':'application/json'},
            body:JSON.stringify({device_id:d.id})
          });
          const result = await r.json();
          if (!r.ok || !result.ok) {
            if (r.status === 429) blockedUntil = Date.now() + (result.retry_after || 60) * 1000;
            throw new Error(result.error || `HTTP ${r.status}`);
          }
          panel.hidden = true;
          await fetchStatus(true);
          note(result.message);
        } catch (e) {
          note(`Device selection failed: ${e.message}`);
          btn.disabled = false;
        }
      };
      line.append(label, btn);
      panel.append(line);
    }
  } catch(e) { info.textContent = `Device lookup failed: ${e.message}`; }
}
$('devices').onclick = findDevices;
setPlaybackIcon(false);
setVolumeIcon(null);
setEnabled(false);
fetchStatus();
// Spotify's public Web API is poll-based; a 5-second foreground check balances latency and quota.
// Never poll the Web API every second. Use the local desktop companion for event-driven updates later.
let lastBackgroundCheckAt = 0;
setInterval(() => {
  if (!document.hidden) {
    fetchStatus();
  } else if (Date.now() - lastBackgroundCheckAt >= HIDDEN_REFRESH_MS) {
    lastBackgroundCheckAt = Date.now();
    fetchStatus();
  }
}, VISIBLE_REFRESH_MS);
setInterval(tick, 250);
let lastFocusRefreshAt = 0;
function refreshWhenReturning() {
  if (document.hidden || Date.now() - lastFocusRefreshAt < 2000) return;
  lastFocusRefreshAt = Date.now();
  fetchStatus(true);
}
document.addEventListener('visibilitychange', () => {
  if (!document.hidden) refreshWhenReturning();
});
window.addEventListener('focus', refreshWhenReturning);
