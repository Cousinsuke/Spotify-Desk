Spotify Desk Thing — Phase 2.4

Fixes:
- Play and pause have identical 56px green circles, identical 28px SVG viewport and
  matching visual height. The pause bars are centered; no per-state CSS size override.
- Clicking play/pause immediately changes the browser icon and freezes/resumes the
  position timer, without waiting for the Spotify Web API roundtrip.
- The browser verifies actions after 0.95s and 3s, with a brief override window to
  avoid flickering back to stale Spotify playback state.
- External Spotify changes are detected with 5-second foreground polling
  (previously 20s), 20-second background polling and an immediate refresh when
  returning to the tab. A Spotify Web API integration cannot provide zero-latency
  external update notifications; the planned desktop companion can do this locally.
- Preserves the dynamic speaker icons and the Spotify Connect device picker.
- Status backend cache TTL adjusted to 5 seconds, so faster polling does not
  repeatedly return the old cached track.

Contents of the PATCH ZIP (root level):
    desk_ui.py            <-- backend cache TTL only
    templates/index.html  <-- versioned assets
    static/ui.css         <-- consistent SVG sizing
    static/ui.js          <-- response optimizations and polling
    README-update.txt

Does NOT include or overwrite .spotify_token.json, .venv, or spotify_test.py.

Installation in WINDOWS POWERSHELL:
  1. Ctrl+C to stop the server.
  2. $Project = "$HOME\Projects\Display-Spotify-Desk-Thing"
  3. $Zip = "$HOME\Downloads\spotify-desk-thing-ui-phase2-4.zip"
  4. Set-Location $Project
  5. Expand-Archive -LiteralPath $Zip -DestinationPath $Project -Force
  6. .\.venv\Scripts\python.exe .\desk_ui.py
  7. Open http://127.0.0.1:8888 and Ctrl+F5.

No new dependencies or OAuth configuration changes.
