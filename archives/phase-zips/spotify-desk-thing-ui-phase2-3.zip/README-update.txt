Spotify Desk Thing UI — Phase 2.3 (visual-only patch)

FIXES:
  - Rounded two-bar PAUSE SVG matching reference picture; same green button as PLAY.
  - Consistent fixed-grid alignment of previous/play-pause/next icons.
  - Speaker icon changes at 0 (mute), 1-33 (low), 34-66 (medium), 67-100 (high).
  - Speaker icon previews new volume while dragging the slider.
  - Cache-busting query parameter on CSS and JavaScript.
  - ZIP files are in the correct root layout (Phase 2.2 mistakenly nested them).

CONTENTS:
  static/ui.js
  static/ui.css
  templates/index.html
  README-update.txt

This patch does not alter desk_ui.py, Spotify authentication, token cache,
your API test files, .venv or backend playback logic.

INSTALL (Windows PowerShell):
  Press Ctrl+C in the server window.
  $Project = "$HOME\Projects\Display-Spotify-Desk-Thing"
  $Zip = "$HOME\Downloads\spotify-desk-thing-ui-phase2-3.zip"
  Set-Location $Project
  Expand-Archive -LiteralPath $Zip -DestinationPath $Project -Force
  .\.venv\Scripts\python.exe .\desk_ui.py

Then Ctrl+F5 at http://127.0.0.1:8888 and verify icon transitions.
The URL of the served JS should include '?v=2.3'.
